<!-- jQuery & Moment-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript" src="js/moment.js"></script>

<!-- Bootstrap & Datepicker CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">

<!-- Bootstrap & Datepicker JavaScript -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>

<!-- Custom CSS -->
<link rel="stylesheet" href="css/style.css">
